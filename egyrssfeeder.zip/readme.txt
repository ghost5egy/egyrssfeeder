=== Plugin Name ===

    Contributors: ghost5egy
    Plugin Name: egyrssfeeder
    Plugin URI: https://github.com/ghost5egy/egyrssfeeder
    Tags: wordpress,plugin,rss
    Author URI: https://ghost5egy47101274.wordpress.com/
    Author: ghost5egy
    Donate link: https://www.paypal.me/AhmedS71
    Requires at least: None
    Tested up to: 1
    Stable tag: 1
    Version: 1

== Description ==
egyrssfeeder is a free wordpress pugin to add posts to your website other sources rss link 


== Installation ==

just upload files to your plugins folder then activate the plugin from wordpress dashboard

== Donations ==

https://www.paypal.me/AhmedS71